<h1>Edit Warga</h1>
<form action="/warga/<?php echo e($warga->id); ?>" method="POST">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <input type="text" name="nama" placeholder="Nama" value="<?php echo e($warga->nama); ?>"/><br>    
    <input type="text" name="nik" placeholder="NIK" value="<?php echo e($warga->nik); ?>"/><br>
    <input type="text" name="no_kk" placeholder="NO. KK" value="<?php echo e($warga->no_kk); ?>"/><br>
    <select name="jenis_kelamin">
        <option value="">Pilih Jenis Kelamin</option>
        <option value="L" <?php if($warga->jenis_kelamin=='L'): ?> 
            selected
        <?php endif; ?>>Laki-laki</option>
        <option value="P" <?php if($warga->jenis_kelamin=='P'): ?> 
            selected
        <?php endif; ?>>Perempuan</option>
    </select><br/>
    <textarea name="alamat" placeholder="Alamat" rows="10"><?php echo e($warga->alamat); ?></textarea><br/>
    <input type="submit" name="submit" value="Update">
</form><?php /**PATH /Users/leo/Coding/php/laravelapp/resources/views/warga/edit.blade.php ENDPATH**/ ?>