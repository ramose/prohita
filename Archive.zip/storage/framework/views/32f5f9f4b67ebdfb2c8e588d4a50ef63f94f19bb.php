<?php $__env->startSection('content'); ?>
<div class="container">
    
    <div class="d-flex justify-content-between">
        <h1>Clients</h1>
        <div>
<a href="/client/create" class="btn btn-primary">Add Client</a>
        </div>
    </div>
<table class="table">
    <tr>
        <th>Name</th>
        <th>Email 1</th>
        <th>Email 2</th>
        <th>Mobile</th>
    </tr>
    <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($w->client_name); ?></td>
        <td><?php echo e($w->client_email_1); ?></td>
        <td><?php echo e($w->client_email_2); ?></td>
        <td><?php echo e($w->client_mobile); ?></td>
        <td><a href="/client/<?php echo e($w->id); ?>/edit" class="btn btn-secondary">Edit</a></td>
        <td><form action="/client/<?php echo e($w->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <input type="submit" value="Delete" class="btn btn-danger">
        </form></td>
    </tr>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
</table>
</div>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/leo/Coding/php/prohita/resources/views/client/index.blade.php ENDPATH**/ ?>