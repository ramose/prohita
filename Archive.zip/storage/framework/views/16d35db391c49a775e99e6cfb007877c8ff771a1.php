<a href="/warga/create">Add Warga</a>
<table border="1">
    <tr>
        <th>Nama</th>
        <th>NIK</th>
        <th>NO. KK</th>
        <th>Jenis Kelamin</th>
        <th>Alamat</th>
    </tr>
    <?php $__currentLoopData = $warga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($w->nama); ?></td>
        <td><?php echo e($w->nik); ?></td>
        <td><?php echo e($w->no_kk); ?></td>
        <td><?php echo e($w->jenis_kelamin); ?></td>
        <td><?php echo e($w->alamat); ?></td>
        <td><a href="/warga/<?php echo e($w->id); ?>/edit">Edit</a></td>
        <td><form action="/warga/<?php echo e($w->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <input type="submit" value="Delete">
        </form></td>
    </tr>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
</table><?php /**PATH /Users/leo/Coding/php/laravelapp/resources/views/warga/index.blade.php ENDPATH**/ ?>