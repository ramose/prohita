<h1>Create Warga</h1>
<form action="/warga/store" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="nama" placeholder="Nama"/><br>    
    <input type="text" name="nik" placeholder="NIK"/><br>
    <input type="text" name="no_kk" placeholder="NO. KK"/><br>
    <select name="jenis_kelamin">
        <option value="">Pilih Jenis Kelamin</option>
        <option value="L">Laki-laki</option>
        <option value="P">Perempuan</option>
    </select><br/>
    <textarea name="alamat" placeholder="Alamat" rows="10"></textarea><br/>
    <input type="submit" name="submit" value="Simpan">
</form><?php /**PATH /Users/leo/Coding/php/laravelapp/resources/views/warga/create.blade.php ENDPATH**/ ?>