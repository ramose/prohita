<h1>Edit Client</h1>
<form action="/client/<?php echo e($client->id); ?>" method="POST">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <input type="text" name="client_id" placeholder="ID" value="<?php echo e($client->client_id); ?>"/><br>
    <input type="text" name="client_name" placeholder="Name" value="<?php echo e($client->client_name); ?>"/><br>
    <input type="text" name="client_email_1" placeholder="Email 1" value="<?php echo e($client->client_email_1); ?>"/><br>
    <input type="text" name="client_email_2" placeholder="Email 2" value="<?php echo e($client->client_email_2); ?>"/><br>
    <input type="text" name="client_mobile" placeholder="Mobile Phone" value="<?php echo e($client->client_mobile); ?>"/><br>
    <input type="submit" name="submit" value="Update">
</form><?php /**PATH /Users/leo/Coding/php/prohita/resources/views/client/edit.blade.php ENDPATH**/ ?>