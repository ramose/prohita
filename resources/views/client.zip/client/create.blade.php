<h1>Add Client</h1>
<form action="/client/store" method="POST">
    @csrf
    <input type="text" name="client_id" placeholder="ID" value=""/><br> 
    <input type="text" name="client_name" placeholder="Name"/><br>    
    <input type="text" name="client_email_1" placeholder="Email 1"/><br>
    <input type="text" name="client_email_2" placeholder="Email 2"/><br>
    <input type="text" name="client_mobile" placeholder="Mobile Phone"/><br>
    <input type="submit" name="submit" value="Save">
</form>